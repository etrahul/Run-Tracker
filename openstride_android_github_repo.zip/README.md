# OpenStride — Open-Source GPS Running, Timer & Energy Tracker (Android + Web)

OpenStride is an MIT-licensed real-time GPS running tracker, countdown timer, calorie/energy tracker, and smart exercise/rest coach.

## GitHub ke through Android par Install karne ke 2 Tarike

### Tarika 1: GitHub Pages PWA (Sabse Aasaan — 1 Minute, Bina APK Build Kiye)
1. Is repository ke saare files apne **GitHub Repository** me upload (push) karein.
2. GitHub repo me **Settings -> Pages** par jayein.
3. **Build and deployment -> Branch** me `main` select karke **Save** karein.
4. 1 minute baad aapko `https://<your-username>.github.io/<repo-name>/` link milega.
5. Apne **Android phone ke Chrome browser** me ye link kholein -> upar `⋮` menu ya **"Install App / Add to Home Screen"** par tap karein.
6. Ye aapke Android phone par full-screen native app ki tarah install ho jayega aur real GPS (`navigator.geolocation`) + Screen Wake Lock kaam karega!

### Tarika 2: GitHub Actions se Direct `.apk` File Banayein (Bina PC/Android Studio ke)
1. Is zip me `.github/workflows/build-android-apk.yml` pehle se configured hai.
2. Jab aap ye files apne GitHub repo me upload karenge, upar **Actions** tab me jayein.
3. **Build Android APK (OpenStride)** workflow automatically chalega aur 2-3 minute me **Artifacts** section me **`OpenStride-Android-APK`** (`app-debug.apk`) तैयार kar dega.
4. Us `.apk` ko apne Android phone me download karke direct install kar lein!
